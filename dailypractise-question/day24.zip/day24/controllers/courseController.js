const courses = [
  { id: 1, name: "React" },
  { id: 2, name: "NodeJS" }
];

exports.getCourses = (req, res) => {
  res.status(200).json(courses);
};