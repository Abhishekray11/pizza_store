import React from 'react';

import { useFormik } from 'formik';

import * as Yup from 'yup';

import { useDispatch } from 'react-redux';

import { addBooking } from './store/actions';

function BookingForm() {

  const dispatch = useDispatch();

  const formik = useFormik({

    initialValues: {

      name: '',

      email: '',

      destination: ''

    },

    validationSchema: Yup.object({

      name: Yup.string()
        .required('Name Required'),

      email: Yup.string()
        .email('Invalid Email')
        .required('Email Required'),

      destination: Yup.string()
        .required('Destination Required')

    }),

    onSubmit: (values, { resetForm }) => {

      dispatch(addBooking(values));

      alert('Booking Confirmed');

      resetForm();
    }
  });

  return (

    <div className="container mt-5">

      <div className="card shadow p-4">

        <h2 className="mb-4">
          Booking Form
        </h2>

        <form onSubmit={formik.handleSubmit}>

          <div className="mb-3">

            <label>Name</label>

            <input
              type="text"
              name="name"
              className="form-control"
              onChange={formik.handleChange}
              value={formik.values.name}
            />

            <small className="text-danger">
              {formik.errors.name}
            </small>

          </div>

          <div className="mb-3">

            <label>Email</label>

            <input
              type="email"
              name="email"
              className="form-control"
              onChange={formik.handleChange}
              value={formik.values.email}
            />

            <small className="text-danger">
              {formik.errors.email}
            </small>

          </div>

          <div className="mb-3">

            <label>Destination</label>

            <input
              type="text"
              name="destination"
              className="form-control"
              onChange={formik.handleChange}
              value={formik.values.destination}
            />

            <small className="text-danger">
              {formik.errors.destination}
            </small>

          </div>

          <button
            type="submit"
            className="btn btn-success"
          >
            Book Now
          </button>

        </form>

      </div>

    </div>
  );
}

export default BookingForm;