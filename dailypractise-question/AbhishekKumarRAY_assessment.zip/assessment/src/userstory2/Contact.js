import React from 'react';

function Contact() {

  return (

    <div className="container mt-5">

      <h2>Contact Us</h2>

      <p>Email : support@travelgo.com</p>

      <p>Phone : +91 9876543210</p>

    </div>
  );
}

export default Contact;