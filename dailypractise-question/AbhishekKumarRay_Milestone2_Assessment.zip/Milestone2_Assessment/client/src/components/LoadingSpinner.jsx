import React from "react";

function LoadingSpinner() {
  return (
    <div className="text-center">
      <h2>Loading...</h2>
    </div>
  );
}

export default LoadingSpinner;