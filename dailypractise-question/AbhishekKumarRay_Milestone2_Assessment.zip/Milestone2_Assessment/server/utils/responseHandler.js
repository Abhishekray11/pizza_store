const successResponse = (
  res,
  data,
  message
) => {
  res.status(200).json({
    success: true,
    message,
    data
  });
};

const errorResponse = (
  res,
  message
) => {
  res.status(500).json({
    success: false,
    message
  });
};

module.exports = {
  successResponse,
  errorResponse
};