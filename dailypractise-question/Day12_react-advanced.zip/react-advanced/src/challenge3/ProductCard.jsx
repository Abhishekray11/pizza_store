function ProductCard({ product }) {

  // Simulating component crash
  if (!product.price) {
    throw new Error(
      "Product price is missing!"
    );
  }

  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: "20px",
        width: "250px",
        borderRadius: "10px",
        margin: "10px",
        boxShadow: "0px 4px 10px rgba(0,0,0,0.1)"
      }}
    >
      <h2>{product.name}</h2>

      <h3>
        ₹ {product.price}
      </h3>
    </div>
  );
}

export default ProductCard;