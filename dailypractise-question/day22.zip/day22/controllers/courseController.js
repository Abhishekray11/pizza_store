const courses = require("../data/courses");

// GET
exports.getCourses = (req, res) => {
  res.json(courses);
};

// POST
exports.createCourse = (req, res) => {
  const course = {
    id: courses.length + 1,
    name: req.body.name,
    duration: req.body.duration
  };

  courses.push(course);

  res.status(201).json(course);
};

// PUT
exports.updateCourse = (req, res) => {
  const course = courses.find(
    c => c.id === parseInt(req.params.id)
  );

  if (!course) {
    return res.status(404).json({
      error: "Course not found"
    });
  }

  course.name = req.body.name;
  course.duration = req.body.duration;

  res.json(course);
};

// DELETE
exports.deleteCourse = (req, res) => {
  const index = courses.findIndex(
    c => c.id === parseInt(req.params.id)
  );

  if (index === -1) {
    return res.status(404).json({
      error: "Course not found"
    });
  }

  courses.splice(index, 1);

  res.json({
    message: "Course deleted"
  });
};