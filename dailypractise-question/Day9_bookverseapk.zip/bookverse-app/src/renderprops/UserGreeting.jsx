function UserGreeting({ render }) {

  const user = "Abhishek";

  return render(user);
}

export default UserGreeting;