import React, { useState } from 'react';

import DestinationCard from './DestinationCard';

import './style.css';

function HomePage() {

  const [count, setCount] = useState(0);

  const addWishlist = () => {
    setCount(count + 1);
  };

  return (

    <div className="container mt-4">

      <h2 className="text-center mb-4">
        Featured Destinations
      </h2>

      <h4 className="text-success mb-4">
        Wishlist Count : {count}
      </h4>

      <div className="row">

        <DestinationCard
          title="Paris"
          price="₹1,20,000"
          image="https://images.unsplash.com/photo-1502602898657-3e91760cbb34"
          addWishlist={addWishlist}
        />

        <DestinationCard
          title="Maldives"
          price="₹95,000"
          image="https://images.unsplash.com/photo-1573843981267-be1999ff37cd"
          addWishlist={addWishlist}
        />

        <DestinationCard
          title="Bali"
          price="₹75,000"
          image="https://images.unsplash.com/photo-1537953773345-d172ccf13cf1"
          addWishlist={addWishlist}
        />

      </div>

    </div>
  );
}

export default HomePage;