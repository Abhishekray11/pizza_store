import React from "react";

import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

import Navbar from "./components/Navbar.jsx";

import Footer from "./components/Footer.jsx";

import HomePage from "./pages/HomePage.jsx";

import AboutPage from "./pages/AboutPage.jsx";

import UsersPage from "./pages/UsersPage.jsx";

import UserDetailPage from "./pages/UserDetailPage.jsx";

import NotFound from "./pages/NotFound.jsx";

import { AppProvider } from "./context/AppContext.jsx";

function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Navbar />

        <div className="container mt-4">
          <Routes>
            <Route
              path="/"
              element={<HomePage />}
            />

            <Route
              path="/about"
              element={<AboutPage />}
            />

            <Route
              path="/users"
              element={<UsersPage />}
            />

            <Route
              path="/users/:id"
              element={<UserDetailPage />}
            />

            <Route
              path="*"
              element={<NotFound />}
            />
          </Routes>
        </div>

        <Footer />
      </BrowserRouter>
    </AppProvider>
  );
}

export default App;