const courses = [
  {
    id: 1,
    name: "React",
    duration: "2 Months"
  }
];

module.exports = courses;