"use strict";
// Class
class Product {
    id;
    name;
    category;
    price;
    stock;
    constructor(id, name, category, price, stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }
    // Method to update stock
    updateStock(newStock) {
        console.log(`Stock updated from ${this.stock} to ${newStock}`);
        this.stock = newStock;
    }
    // Method to update price
    updatePrice(newPrice) {
        console.log(`Price updated from ${this.price} to ${newPrice}`);
        this.price = newPrice;
    }
}
// Tuple Array
let productList = [
    [1, "Laptop"],
    [2, "Phone"]
];
// Map
let productMap = new Map();
// Creating objects
let p1 = new Product(1, "Laptop", "Electronics", 2000, 15);
let p2 = new Product(2, "Phone", "Electronics", 800, 10);
// Add into map
productMap.set(p1.id, p1);
productMap.set(p2.id, p2);
// Update values
p1.updatePrice(3200);
p2.updateStock(25);
// Display products
for (let [id, product] of productMap) {
    console.log("ID:", product.id);
    console.log("Name:", product.name);
    console.log("Category:", product.category);
    console.log("Price:", product.price);
    console.log("Stock:", product.stock);
    console.log("----------------");
}
