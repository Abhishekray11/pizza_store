const request = require("supertest");
const assert = require("assert");
const app = require("../app");

describe("Users API", () => {

  it("GET /api/users", async () => {

    const res = await request(app)
      .get("/api/users");

    assert.strictEqual(res.status, 200);
    assert.ok(Array.isArray(res.body));

  });

});