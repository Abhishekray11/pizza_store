import React from 'react';

function Footer() {

  return (
    <div className="bg-dark text-white text-center p-3 mt-5">

      <h5>© 2026 TravelGo</h5>

    </div>
  );
}

export default Footer;