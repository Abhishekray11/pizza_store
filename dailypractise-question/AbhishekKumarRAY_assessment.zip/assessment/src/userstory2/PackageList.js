import React, {
  useEffect,
  useState
} from 'react';

import axios from 'axios';

import PackageCard from './PackageCard';

function PackageList() {

  const [packages, setPackages] = useState([]);

  useEffect(() => {

    fetchPackages();

  }, []);

  const fetchPackages = async () => {

    try {

      const response = await axios.get(
        'http://localhost:5000/packages'
      );

      setPackages(response.data);

    } catch (error) {

      console.log(error);

    }
  };

  return (

    <div className="container mt-4">

      <h2 className="mb-4">
        Travel Packages
      </h2>

      <div className="row">

        {
          packages.map((item) => (

            <PackageCard
              key={item.id}
              item={item}
            />

          ))
        }

      </div>

    </div>
  );
}

export default PackageList;