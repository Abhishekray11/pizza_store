import ReactDOM from "react-dom";
import "./Modal.css";

function Modal({ closeModal }) {
  return ReactDOM.createPortal(
    <div className="modal-overlay">
      <div className="modal-box">
        <h2>Portal Modal</h2>

        <p>
          This modal is rendered outside the root DOM.
        </p>

        <button onClick={closeModal}>
          Close
        </button>
      </div>
    </div>,
    document.body
  );
}

export default Modal;