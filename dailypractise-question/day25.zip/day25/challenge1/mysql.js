const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'skillsphere'
});

connection.connect((err) => {
    if (err) {
        console.log(err);
        return;
    }

    console.log('MySQL Connected');

    const sql = `
        INSERT INTO courses(title, duration)
        VALUES (?, ?)
    `;

    connection.query(
        sql,
        ['MERN Stack', '3 Months'],
        (err, result) => {
            if (err) throw err;

            console.log('Course Inserted Successfully');
            console.log(result);
            connection.end();
        }
    );
});