const sequelize = require("./db");

const {
  Instructor,
  Course
} = require("./model/association");

async function main() {
  try {

    // Create Tables
    await sequelize.sync({ force: true });

    console.log("Tables Created");

    // Create Instructor
    const instructor = await Instructor.create({
      name: "John"
    });

    // Create Courses
    await Course.create({
      title: "NodeJS",
      InstructorId: instructor.id
    });

    await Course.create({
      title: "ReactJS",
      InstructorId: instructor.id
    });

    await Course.create({
      title: "MongoDB",
      InstructorId: instructor.id
    });

    // Query Instructor with Courses
    const result = await Instructor.findOne({
      where: {
        id: instructor.id
      },
      include: Course
    });

    console.log(JSON.stringify(result, null, 2));

  } catch (err) {
    console.log(err);
  }
}

main();