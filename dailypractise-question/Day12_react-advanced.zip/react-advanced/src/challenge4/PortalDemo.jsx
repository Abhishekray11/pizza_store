import { useState } from "react";
import Modal from "./Modal";

function PortalDemo() {
  const [open, setOpen] = useState(false);

  return (
    <div className="section">
      <h2>Challenge 4: Portals</h2>

      <button onClick={() => setOpen(true)}>
        Open Modal
      </button>

      {open && (
        <Modal closeModal={() => setOpen(false)} />
      )}
    </div>
  );
}

export default PortalDemo;