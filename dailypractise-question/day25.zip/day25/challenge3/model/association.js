const Instructor = require("./Instructor");
const Course = require("./Course");

Instructor.hasMany(Course);
Course.belongsTo(Instructor);

module.exports = {
  Instructor,
  Course
};