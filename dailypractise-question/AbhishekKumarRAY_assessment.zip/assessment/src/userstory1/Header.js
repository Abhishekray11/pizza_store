import React from 'react';

function Header() {

  return (
    <div className="bg-primary text-white text-center p-3">

      <h1>Travel Booking Platform</h1>

    </div>
  );
}

export default Header;