const express = require("express");

const app = express();
const PORT = 3000;


// Challenge 1: Logging Middleware
app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.url} at ${new Date().toISOString()}`);
    next();
});

// Challenge 2: Built-in Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// POST /users
app.post("/users", (req, res) => {
    res.status(201).json({
        message: "User created successfully",
        data: req.body
    });
});


// Challenge 3: Dynamic Templates

app.set("view engine", "ejs");
app.set("views", "./views");

app.get("/courses", (req, res) => {
    const courses = [
        {
            id: 1,
            name: "Node.js",
            trainer: "John"
        },
        {
            id: 2,
            name: "MongoDB",
            trainer: "David"
        },
        {
            id: 3,
            name: "React",
            trainer: "Smith"
        }
    ];

    res.render("courses", { courses });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});