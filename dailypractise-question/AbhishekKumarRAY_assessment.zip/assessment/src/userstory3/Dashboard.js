import React from 'react';

import { useSelector } from 'react-redux';

function Dashboard() {

  const bookings = useSelector(
    state => state.bookings
  );

  return (

    <div className="container mt-5">

      <h2 className="mb-4">
        Booking Dashboard
      </h2>

      <table className="table table-bordered">

        <thead>

          <tr>

            <th>Name</th>

            <th>Email</th>

            <th>Destination</th>

          </tr>

        </thead>

        <tbody>

          {
            bookings.map((item, index) => (

              <tr key={index}>

                <td>{item.name}</td>

                <td>{item.email}</td>

                <td>{item.destination}</td>

              </tr>

            ))
          }

        </tbody>

      </table>

    </div>
  );
}

export default Dashboard;