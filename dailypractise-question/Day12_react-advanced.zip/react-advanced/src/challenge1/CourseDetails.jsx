function CourseDetails() {
  return (
    <div>
      <h3>Course Details</h3>
      <p>React Advanced Concepts Course Loaded Successfully.</p>
    </div>
  );
}

export default CourseDetails;