const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    courseName: String
});

module.exports = mongoose.model(
    'Enrollment',
    enrollmentSchema
);