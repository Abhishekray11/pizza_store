import React from "react";

import { Link } from "react-router-dom";

function UsersPage() {
  const users = [
    {
      id: 1,
      name: "John"
    },
    {
      id: 2,
      name: "David"
    }
  ];

  return (
    <div>
      <h2>Users Page</h2>

      {users.map((user) => (
        <div key={user.id}>
          <Link to={`/users/${user.id}`}>
            {user.name}
          </Link>
        </div>
      ))}
    </div>
  );
}

export default UsersPage;