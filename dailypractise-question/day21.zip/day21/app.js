const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const session = require("express-session");
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const bcrypt = require("bcrypt");

const User = require("./models/User");

const app = express();

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/skillSphereDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
    secret: "mysessionsecret",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

// Passport Local Strategy
passport.use(
    new LocalStrategy(
        { usernameField: "email" },
        async (email, password, done) => {

            const user = await User.findOne({ email });

            if (!user)
                return done(null, false);

            const match = await bcrypt.compare(
                password,
                user.password
            );

            if (!match)
                return done(null, false);

            return done(null, user);
        }
    )
);

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    const user = await User.findById(id);
    done(null, user);
});

// Register Form

app.get("/register", (req, res) => {
    res.sendFile(__dirname + "/views/register.html");
});

// Challenge 1 & 2: User Registration
app.post("/register", async (req, res) => {

    const { name, email, password } = req.body;

    const hashedPassword = await bcrypt.hash(
        password,
        10
    );

    const user = new User({
        name,
        email,
        password: hashedPassword,
        role: "user"
    });

    await user.save();

    console.log("User Saved:", user);

    res.send(`Registration successful for ${name}`);
});

// Login
app.post(
    "/login",
    passport.authenticate("local"),
    (req, res) => {
        res.send("Login Successful");
    }
);

// RBAC Middleware
function isAdmin(req, res, next) {

    if (
        req.isAuthenticated() &&
        req.user.role === "admin"
    ) {
        return next();
    }

    res.status(403).send("Access Denied");
}

app.get("/admin", isAdmin, (req, res) => {
    res.send("Welcome, Admin!");
});

app.listen(3000, () => {
    console.log("Server Running on Port 3000");
});