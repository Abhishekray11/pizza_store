import ProductCard from "./ProductCard";

function ProductSection() {

  const products = [
    {
      id: 1,
      name: "Laptop",
      price: 55000
    },

    {
      id: 2,
      name: "Mobile"
      // price missing intentionally
    },

    {
      id: 3,
      name: "Headphones",
      price: 3000
    }
  ];

  return (
    <div
      style={{
        display: "flex",
        gap: "20px",
        flexWrap: "wrap"
      }}
    >
      {products.map((item) => (
        <ProductCard
          key={item.id}
          product={item}
        />
      ))}
    </div>
  );
}

export default ProductSection;