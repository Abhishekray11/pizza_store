import React from "react";

const StatsCard = React.memo(({ title, value }) => {
  console.log(title, "Rendered");

  return (
    <div
      style={{
        border: "1px solid #ddd",
        padding: "20px",
        margin: "10px",
        borderRadius: "10px",
        width: "200px"
      }}
    >
      <h3>{title}</h3>
      <h1>{value}</h1>
    </div>
  );
});

export default StatsCard;