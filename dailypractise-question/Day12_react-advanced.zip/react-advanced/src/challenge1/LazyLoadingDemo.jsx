import React, { Suspense, lazy, useState } from "react";

const CourseDetails = lazy(() => import("./CourseDetails"));
const InstructorProfile = lazy(() => import("./InstructorProfile"));

function LazyLoadingDemo() {
  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);

  return (
    <div className="section">
      <h2>Challenge 1: Lazy Loading & Code Splitting</h2>

      <button onClick={() => setShowCourse(true)}>
        View Course Details
      </button>

      <button onClick={() => setShowInstructor(true)}>
        View Instructor
      </button>

      <Suspense fallback={<h3>Loading...</h3>}>
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>
    </div>
  );
}

export default LazyLoadingDemo;