import { useEffect, useState } from "react";
import BookStore from "../stores/BookStore";
import BookActions from "../actions/BookAction";
import BookList from "../components/BookList";
import BookService from "../services/BookService";

function Home() {

  const [books, setBooks] = useState([]);

  const service = new BookService();

  useEffect(() => {

    service.getBooks().then((data) => {
      BookActions.loadBooks(data);
    });

    const updateBooks = () => {
      setBooks([...BookStore.getBooks()]);
    };

    BookStore.addChangeListener(updateBooks);

    updateBooks();

    return () => {
      BookStore.removeChangeListener(updateBooks);
    };

  }, []);

  return (
    <div>

      <h1 className="heading">
        All Books
      </h1>

      <BookList books={books} />

    </div>
  );
}

export default Home;