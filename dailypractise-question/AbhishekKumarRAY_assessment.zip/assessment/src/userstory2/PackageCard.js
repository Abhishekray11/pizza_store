import React from 'react';

import PropTypes from 'prop-types';

function PackageCard({ item }) {

  return (

    <div className="col-md-4">

      <div className="card shadow p-3 mb-4">

        <h3>{item.name}</h3>

        <p>
          Location : {item.location}
        </p>

        <p>
          Price : ₹{item.price}
        </p>

      </div>

    </div>
  );
}

PackageCard.propTypes = {
  item: PropTypes.object
};

export default PackageCard;