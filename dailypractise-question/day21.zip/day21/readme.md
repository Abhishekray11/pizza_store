Create Admin User in MongoDB

Insert one admin manually:

db.users.insertOne({
   name:"Admin",
   email:"admin@gmail.com",
   password:"$2b$10$exampleHashedPassword",
   role:"admin"
})

Or update an existing user:

db.users.updateOne(
   { email:"admin@gmail.com" },
   {
      $set:{ role:"admin" }
   }
)