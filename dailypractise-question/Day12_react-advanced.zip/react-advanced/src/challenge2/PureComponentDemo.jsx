import { useState } from "react";
import StatsCard from "./StatsCard";

function PureComponentDemo() {
  const [users, setUsers] = useState(100);
  const [sales] = useState(500);

  return (
    <div className="section">
      <h2>Challenge 2: Pure Components</h2>

      <button onClick={() => setUsers(users + 1)}>
        Simulate Update
      </button>

      <div style={{ display: "flex" }}>
        <StatsCard title="Users" value={users} />
        <StatsCard title="Sales" value={sales} />
      </div>
    </div>
  );
}

export default PureComponentDemo;