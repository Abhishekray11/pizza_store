const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const uploadRoutes = require("./routes/uploadRoutes");

const app = express();

const server = http.createServer(app);

const io = new Server(server);

app.use(express.json());

//File Upload Route 
app.use("/upload", uploadRoutes);

//Serve Uploaded PDFs 
app.use(
  "/materials",
  express.static("uploads")
);

//Chat Page 
app.use(
  express.static("public")
);

// Socket.io 

io.on("connection", (socket) => {

  console.log("User Connected");

  socket.on("chatMessage", (msg) => {

    io.emit("chatMessage", msg);

  });

  socket.on("disconnect", () => {

    console.log("User Disconnected");

  });

});

const PORT = 3000;

server.listen(PORT, () => {

  console.log(
    `Server running on port ${PORT}`
  );

});