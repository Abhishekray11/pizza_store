function InstructorProfile() {
  return (
    <div>
      <h3>Instructor Profile</h3>
      <p>Instructor: Abhishek Kumar Ray</p>
    </div>
  );
}

export default InstructorProfile;