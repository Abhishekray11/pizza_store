import ErrorBoundary from "./ErrorBoundary";
import ProductSection from "./ProductSection";

function ErrorBoundaryDemo() {
  return (
    <div className="section">
      <h1>
        Challenge 3: Error Boundary
      </h1>

      <p>
        Product cards below are wrapped
        inside Error Boundary.
      </p>

      <ErrorBoundary>
        <ProductSection />
      </ErrorBoundary>

      <h2>
        Other UI Still Working
      </h2>

      <button>
        Normal Button
      </button>
    </div>
  );
}

export default ErrorBoundaryDemo;