import { useEffect, useState } from "react";
import axios from "axios";
import BookCard from "../components/BookCard";
import withLoader from "../hoc/withLoader";
import UserGreeting from "../renderprops/UserGreeting";
import Greeting from "../components/Greeting";

function Home() {

  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {

    axios
      .get("http://localhost:3001/books")
      .then((response) => {
        setBooks(response.data);
        setLoading(false);
      });

  }, []);

  const BookList = () => (
    <div className="book-container">
      {
        books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))
      }
    </div>
  );

  const BookListWithLoader = withLoader(BookList);

  return (
    <div>

      <UserGreeting
        render={(user) => <Greeting name={user} />}
      />

      <BookListWithLoader loading={loading} />

    </div>
  );
}

export default Home;