import { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

function BookDetails() {

  const { id } = useParams();

  const [book, setBook] = useState(null);

  useEffect(() => {

    axios
      .get(`http://localhost:3001/books/${id}`)
      .then((response) => {
        setBook(response.data);
      });

  }, [id]);

  if (!book) {
    return <h2>Loading...</h2>;
  }

  return (
    <div className="details">

      <h1>{book.title}</h1>

      <h3>{book.author}</h3>

      <p>{book.description}</p>

    </div>
  );
}

export default BookDetails;