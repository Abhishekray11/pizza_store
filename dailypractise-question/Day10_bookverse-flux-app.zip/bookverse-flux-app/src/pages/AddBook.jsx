import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import BookActions from "../actions/BookAction";
import BookService from "../services/BookService";
import { useNavigate } from "react-router-dom";

function AddBook() {

  const navigate = useNavigate();
  const service = new BookService();

  const initialValues = {
    title: "",
    author: "",
    price: "",
  };

  const validationSchema = Yup.object({

    title: Yup.string()
      .required("Title is required"),

    author: Yup.string()
      .required("Author is required"),

    price: Yup.number()
      .required("Price is required"),

  });

  const onSubmit = async (values, { resetForm }) => {

    const newBook = {
      ...values,
      price: Number(values.price),
    };

    const savedBook = await service.addBook(newBook);

    BookActions.addBook(savedBook);

    alert("Book Added Successfully");

    resetForm();

    navigate("/");
  };

  return (
    <div className="form-container">

      <h1>Add New Book</h1>

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >

        <Form>

          <Field
            type="text"
            name="title"
            placeholder="Enter Title"
          />

          <ErrorMessage
            name="title"
            component="div"
            className="error"
          />

          <Field
            type="text"
            name="author"
            placeholder="Enter Author"
          />

          <ErrorMessage
            name="author"
            component="div"
            className="error"
          />

          <Field
            type="number"
            name="price"
            placeholder="Enter Price"
          />

          <ErrorMessage
            name="price"
            component="div"
            className="error"
          />

          <button type="submit">
            Add Book
          </button>

        </Form>

      </Formik>

    </div>
  );
}

export default AddBook;