const request = require("supertest");
const app = require("../app");

describe("Courses API", () => {

  it("should return all courses", async () => {

    const response = await request(app)
      .get("/api/courses");

    if (response.status !== 200) {
      throw new Error("Expected status 200");
    }

    if (!Array.isArray(response.body)) {
      throw new Error("Response should be an array");
    }

  });

});