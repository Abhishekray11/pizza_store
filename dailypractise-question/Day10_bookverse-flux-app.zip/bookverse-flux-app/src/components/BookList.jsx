import BookCard from "./BookCard";

function BookList({ books }) {

  return (
    <div className="book-container">

      {
        books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))
      }

    </div>
  );
}

export default BookList;