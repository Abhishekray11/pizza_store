const express = require("express");

const router = express.Router();

const {
  getCourses,
  createCourse,
  updateCourse,
  deleteCourse
} = require("../controllers/courseController");

const {
  courseValidation,
  validate
} = require("../middleware/validation");

router.get("/", getCourses);

router.post(
  "/",
  courseValidation,
  validate,
  createCourse
);

router.put("/:id", updateCourse);

router.delete("/:id", deleteCourse);

module.exports = router;