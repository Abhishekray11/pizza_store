import React, { Component } from "react";

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);

    this.state = {
      hasError: false,
      errorMessage: ""
    };
  }

  // Updates state when error occurs
  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      errorMessage: error.message
    };
  }

  // Logs error details
  componentDidCatch(error, errorInfo) {
    console.log("Error Caught:", error);
    console.log("Error Info:", errorInfo);

    // Mock Monitoring API
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
      body: JSON.stringify({
        error: error.toString(),
        info: errorInfo.componentStack
      }),
      headers: {
        "Content-type": "application/json"
      }
    })
      .then((response) => response.json())
      .then((data) => console.log("Logged to API:", data))
      .catch((err) => console.log(err));
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            padding: "20px",
            border: "2px solid red",
            borderRadius: "10px",
            backgroundColor: "#ffe5e5",
            marginTop: "20px"
          }}
        >
          <h2 style={{ color: "red" }}>
            Something went wrong!
          </h2>

          <p>
            {this.state.errorMessage}
          </p>

          <button
            onClick={() =>
              this.setState({
                hasError: false,
                errorMessage: ""
              })
            }
          >
            Retry
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;