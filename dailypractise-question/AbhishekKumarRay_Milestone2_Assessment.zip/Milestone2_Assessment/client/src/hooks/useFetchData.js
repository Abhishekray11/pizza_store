import { useEffect, useState } from "react";

import axios from "axios";

function useFetchData(url) {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get(url).then((response) => {
      setData(response.data);
    });
  }, [url]);

  return data;
}

export default useFetchData;