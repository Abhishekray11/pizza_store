import axios from "axios";

const API = "http://localhost:3002/books";

class BookService {

  async getBooks() {
    const response = await axios.get(API);
    return response.data;
  }

  async addBook(book) {
    const response = await axios.post(API, book);
    return response.data;
  }
}

export default BookService;