import { Link } from "react-router-dom";

function BookCard({ book }) {
  return (
    <div className="card">
      <h3>{book.title}</h3>
      <p>{book.author}</p>

      <Link to={`/book/${book.id}`}>
        <button>View Details</button>
      </Link>
    </div>
  );
}

export default BookCard;