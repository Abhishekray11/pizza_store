import React from "react";

import FormComponent from "../components/FormComponent.jsx";

function HomePage() {
  return (
    <>
      <h2>Home Page</h2>

      <FormComponent />
    </>
  );
}

export default HomePage;