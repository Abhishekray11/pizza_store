import React from "react";

import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar navbar-dark bg-dark px-4">
      <Link
        to="/"
        className="navbar-brand"
      >
        Dashboard
      </Link>

      <div>
        <Link
          to="/"
          className="btn btn-light me-2"
        >
          Home
        </Link>

        <Link
          to="/about"
          className="btn btn-light me-2"
        >
          About
        </Link>

        <Link
          to="/users"
          className="btn btn-light"
        >
          Users
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;