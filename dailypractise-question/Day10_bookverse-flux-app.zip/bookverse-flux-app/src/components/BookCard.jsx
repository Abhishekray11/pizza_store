function BookCard({ book }) {

  return (
    <div className="card">

      <h3>{book.title}</h3>

      <p>Author: {book.author}</p>

      <h4>₹ {book.price}</h4>

    </div>
  );
}

export default BookCard;