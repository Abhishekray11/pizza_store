import React from 'react';

import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Link
} from 'react-router-dom';

import Header from './userstory1/Header';
import Footer from './userstory1/Footer';

import HomePage from './userstory1/HomePage';

import PackageList from './userstory2/PackageList';

import Contact from './userstory2/Contact';

import BookingForm from './userstory3/BookingForm';

import Dashboard from './userstory3/Dashboard';

import ErrorBoundary from './userstory3/ErrorBoundary';

function App() {

  return (

    <Router>

      <div className="d-flex flex-column min-vh-100">

        <Header />

        <nav className="navbar navbar-dark bg-dark px-4">

          <Link
            className="text-white text-decoration-none me-4"
            to="/home"
          >
            Home
          </Link>

          <Link
            className="text-white text-decoration-none me-4"
            to="/packages"
          >
            Packages
          </Link>

          <Link
            className="text-white text-decoration-none me-4"
            to="/contact"
          >
            Contact
          </Link>

          <Link
            className="text-white text-decoration-none"
            to="/dashboard"
          >
            Dashboard
          </Link>

        </nav>

        <main className="flex-grow-1 py-4">

          <ErrorBoundary>

            <Routes>

              <Route
                path="/"
                element={<Navigate to="/home" />}
              />

              <Route
                path="/home"
                element={<HomePage />}
              />

              <Route
                path="/packages"
                element={<PackageList />}
              />

              <Route
                path="/contact"
                element={<BookingForm />}
              />

              <Route
                path="/dashboard"
                element={<Dashboard />}
              />

            </Routes>

          </ErrorBoundary>

        </main>

        <Footer />

      </div>

    </Router>
  );
}

export default App;
