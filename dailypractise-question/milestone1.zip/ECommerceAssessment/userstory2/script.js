const container = document.getElementById("productContainer");
const loading = document.getElementById("loading");
const filter = document.getElementById("categoryFilter");

let allProducts = [];

async function fetchProducts() {
    try {
        loading.style.display = "block";
        const response = await fetch("products.json");
        if(!response.ok) {
            throw new Error("Failed to fetch"); }
        const data = await response.json();
        allProducts = data;
        displayProducts(allProducts);
        loading.style.display = "none";
    }
    catch(error) {
        loading.innerHTML = "Error loading products";
        console.log(error);
    }
}

function displayProducts(products) {
    container.innerHTML = "";
    products.forEach(product => {
        const div = document.createElement("div");
        div.classList.add("card");
        div.innerHTML = `
            <h3>${product.name}</h3>
            <p>Category: ${product.category}</p>
            <p>Price: $${product.price}</p>`;
        container.appendChild(div);
    });
}

filter.addEventListener("change", () => {
    const selected = filter.value;
    if(selected === "All") {
        displayProducts(allProducts);
    }
    else {
        const filtered = allProducts.filter(product =>
            product.category === selected);
        displayProducts(filtered);
    }
});

fetchProducts();