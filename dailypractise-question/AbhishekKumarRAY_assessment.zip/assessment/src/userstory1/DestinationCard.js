import React from 'react';

function DestinationCard(props) {

  return (

    <div className="col-md-4">

      <div className="card shadow mb-4">

        <img
          src={props.image}
          alt={props.title}
          className="card-img-top"
          height="250"
        />

        <div className="card-body">

          <h3>{props.title}</h3>

          <p>{props.price}</p>

          <button
            className="btn btn-success"
            onClick={props.addWishlist}
          >
            Add To Wishlist
          </button>

        </div>

      </div>

    </div>
  );
}

export default DestinationCard;