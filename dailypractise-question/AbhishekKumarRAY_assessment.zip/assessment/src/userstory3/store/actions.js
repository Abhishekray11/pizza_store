export const addBooking = (data) => {

  return {

    type: 'ADD_BOOKING',

    payload: data

  };
};