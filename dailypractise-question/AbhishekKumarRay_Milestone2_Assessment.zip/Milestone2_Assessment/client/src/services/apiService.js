import axios from "axios";

const API =
  "https://jsonplaceholder.typicode.com/users";

export const getUsers = async () => {
  return await axios.get(API);
};