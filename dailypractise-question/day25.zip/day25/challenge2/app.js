const mongoose = require('mongoose');
const Enrollment = require('./Model/enrollment');

mongoose.connect('mongodb://127.0.0.1:27017/skillsphere');

async function getEnrollments() {
    const data = await Enrollment.find()
        .populate('userId');

    console.log(data);
}

getEnrollments();

