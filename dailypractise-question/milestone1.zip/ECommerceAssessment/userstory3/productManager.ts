
interface IProduct {
    id: number;
    name: string;
    category: string;
    price: number;
    stock: number;
}

class Product implements IProduct {

    id: number;
    name: string;
    category: string;
    price: number;
    stock: number;

    constructor(
        id: number,
        name: string,
        category: string,
        price: number,
        stock: number
    ) {

        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    updateStock(newStock: number): void {
        console.log(`Stock updated from ${this.stock} to ${newStock}`);
        this.stock = newStock;
    }

    updatePrice(newPrice: number): void {
        console.log(`Price updated from ${this.price} to ${newPrice}`);
        this.price = newPrice;
    }
}

let productList: [number, string][] = [
    [1, "Laptop"],
    [2, "Phone"]
];

let productMap = new Map<number, Product>();
let p1 = new Product(1, "Laptop", "Electronics", 2000, 15);
let p2 = new Product(2, "Phone", "Electronics", 800, 10);
productMap.set(p1.id, p1);
productMap.set(p2.id, p2);
p1.updatePrice(3200);
p2.updateStock(25);

for(let [id, product] of productMap) {
    console.log("ID:", product.id);
    console.log("Name:", product.name);
    console.log("Category:", product.category);
    console.log("Price:", product.price);
    console.log("Stock:", product.stock);
    console.log("----------------");
}