import { useState } from 'react';

function useBooking() {

  const [loading, setLoading] =
    useState(false);

  const submitBooking = (data) => {

    setLoading(true);

    setTimeout(() => {

      console.log(data);

      setLoading(false);

      alert('Booking Success');

    }, 2000);
  };

  return {

    loading,

    submitBooking

  };
}

export default useBooking;