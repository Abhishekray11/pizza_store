const express = require("express");

const app = express();

app.use(
  "/api/courses",
  require("./routes/courseRoutes")
);

app.use(
  "/api/users",
  require("./routes/userRoutes")
);

app.get("/status", (req, res) => {
  res.send("App is live");
});

module.exports = app;