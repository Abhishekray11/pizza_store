const express = require("express");

const app = express();

const courseRoutes = require("./routes/courseRoutes");
const limiter = require("./middleware/rateLimiter");
const errorHandler = require("./middleware/errorHandler");

app.use(express.json());

app.use("/api/v1/courses", limiter, courseRoutes);

app.use(errorHandler);

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});