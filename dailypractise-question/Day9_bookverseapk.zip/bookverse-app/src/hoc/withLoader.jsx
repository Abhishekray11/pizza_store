import LoadingSpinner from "../components/LoadingSpin";

const withLoader = (WrappedComponent) => {
  return function EnhancedComponent({ loading, ...props }) {

    if (loading) {
      return <LoadingSpinner />;
    }

    return <WrappedComponent {...props} />;
  };
};

export default withLoader;