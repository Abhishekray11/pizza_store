import { EventEmitter } from "events";
import AppDispatcher from "../dispatcher/AppDispatcher";

let books = [];

class BookStore extends EventEmitter {

  getBooks() {
    return books;
  }

  emitChange() {
    this.emit("change");
  }

  addChangeListener(callback) {
    this.on("change", callback);
  }

  removeChangeListener(callback) {
    this.removeListener("change", callback);
  }
}

const store = new BookStore();

AppDispatcher.register((action) => {

  switch (action.type) {

    case "LOAD_BOOKS":
      books = action.payload;
      store.emitChange();
      break;

    case "ADD_BOOK":
      books.push(action.payload);
      store.emitChange();
      break;

    default:
      break;
  }
});

export default store;