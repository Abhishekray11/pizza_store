const express = require("express");
const router = express.Router();

const upload = require("../middleware/uploadMiddleware");

router.post(
  "/",
  upload.single("material"),
  (req, res) => {
    res.json({
      message: `File uploaded successfully: ${req.file.filename}`
    });
  }
);

module.exports = router;