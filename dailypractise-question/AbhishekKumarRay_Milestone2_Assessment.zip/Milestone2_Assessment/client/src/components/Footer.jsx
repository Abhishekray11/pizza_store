import React from "react";

function Footer() {
  return (
    <footer className="bg-primary text-white text-center p-3 mt-4">
      React Dashboard Footer
    </footer>
  );
}

export default Footer;