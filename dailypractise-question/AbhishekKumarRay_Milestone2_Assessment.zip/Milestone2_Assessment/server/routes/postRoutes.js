const express = require("express");

const router = express.Router();

const {
  getPosts,
  createPost
} = require("../controllers/postController");

const authMiddleware = require(
  "../middleware/authMiddleware"
);

router.get("/", getPosts);

router.post(
  "/",
  authMiddleware,
  createPost
);

module.exports = router;