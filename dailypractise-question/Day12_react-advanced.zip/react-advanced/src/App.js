import LazyLoadingDemo from "./challenge1/LazyLoadingDemo";
import PureComponentDemo from "./challenge2/PureComponentDemo";
import ErrorBoundaryDemo from "./challenge3/ErrorBoundaryDemo";
import PortalDemo from "./challenge4/PortalDemo";

function App() {
  return (
    <div>
      <h1 className="main-title">
        ReactJS Advanced Concepts
      </h1>

      <LazyLoadingDemo />
      <PureComponentDemo />
      <ErrorBoundaryDemo />
      <PortalDemo />
    </div>
  );
}

export default App;