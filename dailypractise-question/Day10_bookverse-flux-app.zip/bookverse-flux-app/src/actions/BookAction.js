import AppDispatcher from "../dispatcher/AppDispatcher";

const BookActions = {

  loadBooks(books) {
    AppDispatcher.dispatch({
      type: "LOAD_BOOKS",
      payload: books,
    });
  },

  addBook(book) {
    AppDispatcher.dispatch({
      type: "ADD_BOOK",
      payload: book,
    });
  },
};

export default BookActions;