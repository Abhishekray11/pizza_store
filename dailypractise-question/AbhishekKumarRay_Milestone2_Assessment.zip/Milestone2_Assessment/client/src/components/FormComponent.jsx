import React from "react";

import {
  Formik,
  Form,
  Field,
  ErrorMessage
} from "formik";

import validationSchema from "../utils/validation";

function FormComponent() {
  const initialValues = {
    name: "",
    email: ""
  };

  const handleSubmit = (values) => {
    console.log(values);
  };

  return (
    <div className="card p-4">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <Field
            type="text"
            name="name"
            placeholder="Enter Name"
            className="form-control mb-2"
          />

          <ErrorMessage
            name="name"
            component="div"
            className="text-danger"
          />

          <Field
            type="email"
            name="email"
            placeholder="Enter Email"
            className="form-control mb-2"
          />

          <ErrorMessage
            name="email"
            component="div"
            className="text-danger"
          />

          <button
            type="submit"
            className="btn btn-primary"
          >
            Submit
          </button>
        </Form>
      </Formik>
    </div>
  );
}

export default FormComponent;